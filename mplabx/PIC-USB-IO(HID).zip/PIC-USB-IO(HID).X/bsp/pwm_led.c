//////////////////////////////////////////////////
//  LED PWM ライブラリ
//  PIC: PIC24FJ64GB002
//  PWM: OC1(Blue cathode),OC2(RED cathode),OC3(GREEN cathode)

#include <xc.h>

//////////////////////////////////////////////////
// 定数
#define  PWM_PERIOD 1024 // PWM周期

#define LED_B_CATHODE LATBbits.LATB0
#define LED_R_CATHODE LATBbits.LATB1
#define LED_G_CATHODE LATBbits.LATB2

#define LED_B_CATHODE_TRIS TRISBbits.TRISB0
#define LED_R_CATHODE_TRIS TRISBbits.TRISB1
#define LED_G_CATHODE_TRIS TRISBbits.TRISB2


//////////////////////////////////////////////////
// 変数

//////////////////////////////////////////////////
// PWM_LED点灯処理　初期化
void PWM_LED_init( void )
{
    LED_B_CATHODE = 0;
    LED_R_CATHODE = 0;
    LED_G_CATHODE = 0;

    LED_B_CATHODE_TRIS = 0;
    LED_R_CATHODE_TRIS = 0;
    LED_G_CATHODE_TRIS = 0;

    RPOR0bits.RP0R = 18;    // RB0/RP0  OC1
    RPOR0bits.RP1R = 19;    // RB1/RP1  OC2
    RPOR1bits.RP2R = 20;    // RB2/RP2  OC3

    // OC1 出力コンペア リセット
    OC1CON1 = 0x0000;
    OC1CON2 = 0x0000;
    // PWM 周期設定
    OC1R = 0;               // デューティ0%
    OC1RS = PWM_PERIOD - 1; // 周期
    // PWM 設定
    OC1CON2bits.SYNCSEL = 0x1f;     // トリガ/ 同期ソース選択ビット
    OC1CON2bits.OCTRIG = 0;         //
    OC1CON1bits.OCTSEL = 0b111;     // システムクロック
    OC1CON1bits.TRIGMODE = 1;       // トリガステータス モード選択
    OC1CON1bits.OCM = 6;            // モード6

    // OC2 出力コンペア リセット
    OC2CON1 = 0x0000;
    OC2CON2 = 0x0000;
    // PWM 周期設定
    OC2R = 0;               // デューティ0%
    OC2RS = PWM_PERIOD - 1; // 周期
    // PWM 設定
    OC2CON2bits.SYNCSEL = 0x1f;     // トリガ/ 同期ソース選択ビット
    OC2CON2bits.OCTRIG = 0;         //
    OC2CON1bits.OCTSEL = 0b111;     // システムクロック
    OC2CON1bits.TRIGMODE = 1;       // トリガステータス モード選択
    OC2CON1bits.OCM = 6;            // モード6

    // OC3 出力コンペア リセット
    OC3CON1 = 0x0000;
    OC3CON2 = 0x0000;
    // PWM 周期設定
    OC3R = 0;               // デューティ0%
    OC3RS = PWM_PERIOD - 1; // 周期
    // PWM 設定
    OC3CON2bits.SYNCSEL = 0x1f;     // トリガ/ 同期ソース選択ビット
    OC3CON2bits.OCTRIG = 0;         //
    OC3CON1bits.OCTSEL = 0b111;     // システムクロック
    OC3CON1bits.TRIGMODE = 1;       // トリガステータス モード選択
    OC3CON1bits.OCM = 6;            // モード6

}

//////////////////////////////////////////////////
// PWM_LED点灯処理
void PWM_LED_set( unsigned int r, unsigned int g, unsigned int b )
{
    // PWM値をセット
    OC1R = r & 0x3ff;
    OC2R = g & 0x3ff;
    OC3R = b & 0x3ff;
    
}
